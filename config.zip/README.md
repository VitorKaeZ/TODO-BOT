## TODOBOT

TODOBOT are a to-do-list and suggestion bot.

Create an archive .env and set this

```
TOKEN_APP=
CLIENT_ID=
```
